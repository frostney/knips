export { cn } from 'cnfast';
